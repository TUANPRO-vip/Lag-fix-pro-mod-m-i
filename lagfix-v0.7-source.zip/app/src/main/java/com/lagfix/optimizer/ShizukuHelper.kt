package com.lagfix.optimizer

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

/**
 * Lop ho tro Shizuku o muc toi thieu: kiem tra Shizuku co dang chay khong,
 * kiem tra/xin quyen, va chay lenh "pm grant" de cap WRITE_SECURE_SETTINGS
 * cho chinh app nay (dung cho tinh nang giam hieu ung).
 *
 * Buoc chay lenh dung reflection vi Shizuku.newProcess khong nam trong API
 * cong khai on dinh (co the thay doi giua cac phien ban Shizuku); neu khong
 * goi duoc se tra ve false va man hinh se chi dan dung lenh ADB thay the.
 */
object ShizukuHelper {
    const val REQUEST_CODE = 9001

    fun isAvailable(): Boolean = try {
        Shizuku.pingBinder()
    } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        isAvailable() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun runCommand(cmd: Array<String>): Boolean {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val process = m.invoke(null, cmd, null, null) ?: return false
            val waitFor = process.javaClass.getMethod("waitFor")
            val exit = waitFor.invoke(process) as? Int
            exit == 0
        } catch (_: Throwable) {
            false
        }
    }

    fun grantWriteSecureSettings(packageName: String): Boolean =
        runCommand(arrayOf("pm", "grant", packageName, "android.permission.WRITE_SECURE_SETTINGS"))
}
